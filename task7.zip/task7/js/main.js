// $('.carousel').carousel();

// $('.carousel').carousel({
//   interval: 2000,
//   pause: 'hover',
//   wrap: true
// });

